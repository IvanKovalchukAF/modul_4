CREATE VIEW customer_product_lines AS
  SELECT
    `c`.`customerNumber`                                    AS `customerNumber`,
    `c`.`customerName`                                      AS `customerName`,
    group_concat(DISTINCT `pl`.`productLine` SEPARATOR ',') AS `product_line`
  FROM ((((`classicmodels`.`customers` `c`
    JOIN `classicmodels`.`orders` `o` ON ((`c`.`customerNumber` = `o`.`customerNumber`))) JOIN
    `classicmodels`.`orderdetails` `od` ON ((`o`.`orderNumber` = `od`.`orderNumber`))) JOIN
    `classicmodels`.`products` `p` ON ((`p`.`productCode` = `od`.`productCode`))) JOIN
    `classicmodels`.`productlines` `pl` ON ((`pl`.`productLine` = `p`.`productLine`)))
  GROUP BY `c`.`customerNumber`;
